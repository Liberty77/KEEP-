//
//  ViewController.swift
//  KEEP广告
//
//  Created by mac on 16/5/29.
//  Copyright © 2016年 mac. All rights reserved.
//

import UIKit
import AVFoundation
import MediaPlayer
import SnapKit


class ViewController: UIViewController,UIScrollViewDelegate {
    
    var avaudioSession: AVAudioSession?
    
    var moviePlayer: MPMoviePlayerController!
    var timer: NSTimer!
    
    var btnRegiset: UIButton!
    var btnLogin: UIButton!
    var pageControl: UIPageControl!
    var showLabel: UILabel!
    var scrollView: UIScrollView!
    var imgKeep: UIImageView!
   
    
    let sportsArr:[String] = ["我运动我快乐","运动使人年轻","运动使人激情","运动挑战无极限"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        createPlayer()
        initViews()
        setUpTimer()
    }
    
    
    func createPlayer(){
        avaudioSession = AVAudioSession.sharedInstance()
        
        do{
            try self.avaudioSession?.setCategory(AVAudioSessionCategoryAmbient)
        }catch{error}
        
        let urlStr = NSBundle.mainBundle().pathForResource("keep.mp4", ofType: nil)
        let url = NSURL(fileURLWithPath: urlStr!)
        moviePlayer = MPMoviePlayerController(contentURL: url)
        moviePlayer.play()
        moviePlayer.view.frame = self.view.bounds;
        self.view.addSubview(moviePlayer.view)
        moviePlayer.shouldAutoplay = true
        moviePlayer.controlStyle = .None
        moviePlayer.fullscreen = true
        moviePlayer.repeatMode = .One
        NSNotificationCenter.defaultCenter().addObserver(self, selector: #selector(playBackStateChange), name: MPMoviePlayerPlaybackStateDidChangeNotification, object: moviePlayer)
    }
    
    
    
    func initViews(){
        
        scrollView = UIScrollView()
        scrollView.pagingEnabled = true
        scrollView.contentSize = CGSizeMake(self.view.bounds.width * 4 , 60)
        scrollView.userInteractionEnabled = true
        scrollView.backgroundColor = UIColor.clearColor()
        scrollView.showsVerticalScrollIndicator = false
        scrollView.showsHorizontalScrollIndicator = false
        scrollView.delegate = self
        scrollView.scrollsToTop = false
        scrollView.bounces = false
        view.addSubview(scrollView)
        
        scrollView.snp_makeConstraints { (make) in
            make.width.equalTo(self.view.frame.width)
            make.top.equalTo( self.view)
            make.bottom.equalTo(self.view.snp_bottom).offset(-100)
        }
        
        for i in 0..<sportsArr.count {
            showLabel = UILabel()
            showLabel.frame = CGRectMake(CGFloat(Float(self.view.bounds.width)*Float(i)), self.view.bounds.height - 150,self.view.bounds.width, 50)
            showLabel.text = sportsArr[i]
            showLabel.font = UIFont.systemFontOfSize(20)
            showLabel.textAlignment = .Center
            showLabel.textColor = UIColor.whiteColor()
            scrollView.addSubview(showLabel)
        }
        
        pageControl = UIPageControl()
        pageControl.numberOfPages = 4
        pageControl.currentPage = 0
        pageControl.currentPageIndicatorTintColor = UIColor.greenColor()
        pageControl.pageIndicatorTintColor = UIColor.whiteColor()
        pageControl.userInteractionEnabled = true
        
        pageControl.addTarget(self, action: #selector(pageChanged(_:)), forControlEvents: UIControlEvents.ValueChanged)
        view.addSubview(pageControl)
        pageControl.snp_makeConstraints { (make) in
            make.width.equalTo(100)
            make.height.equalTo(20)
            make.top.equalTo(showLabel.snp_bottom).offset(5)
            make.centerX.equalTo(self.view.snp_centerX)
        }
        
        btnRegiset = UIButton()
        btnRegiset.layer.cornerRadius = 3
        btnRegiset.alpha = 0.4
        btnRegiset.backgroundColor = UIColor.blackColor()
        btnRegiset.setTitle("注册", forState: .Normal)
        btnRegiset.setTitleColor(UIColor.whiteColor(), forState: .Normal)
        btnRegiset.setTitleColor(UIColor.blackColor(), forState: .Highlighted)
        btnRegiset.titleLabel?.textAlignment = .Center
        btnRegiset.titleLabel?.font = UIFont.systemFontOfSize(20)
        self.view.addSubview(btnRegiset)
        btnRegiset.snp_makeConstraints { (make) in
            make.height.equalTo(50)
            make.width.equalTo((self.view.bounds.width - 60)/2)
            make.bottom.equalTo(self.view.snp_bottom).offset(-10)
            make.left.equalTo(self.view.snp_left).offset(20)
        }
        
        btnLogin = UIButton()
        btnLogin.layer.cornerRadius = 3
        btnLogin.alpha = 0.4
        btnLogin.backgroundColor = UIColor.whiteColor()
        btnLogin.setTitle("登录", forState: .Normal)
        btnLogin.setTitleColor(UIColor.blackColor(), forState: .Normal)
        btnLogin.setTitleColor(UIColor.whiteColor(), forState: .Highlighted)
        btnLogin.titleLabel?.font = UIFont.systemFontOfSize(20)
        btnLogin.titleLabel?.textAlignment = .Center
        self.view.addSubview(btnLogin)
        btnLogin.snp_makeConstraints { (make) in
            make.height.equalTo(50)
            make.width.equalTo((self.view.bounds.width - 60)/2)
            make.bottom.equalTo(self.view.snp_bottom).offset(-10)
            make.right.equalTo(self.view.snp_right).offset(-20)
        }

        imgKeep = UIImageView()
        imgKeep.image = UIImage(named: "keep6")
        imgKeep.userInteractionEnabled = true
        self.view.addSubview(imgKeep)
        imgKeep.snp_makeConstraints { (make) in
            make.width.equalTo(167)
            make.height.equalTo(75)
            make.top.equalTo(self.view.snp_top).offset(230)
            make.centerX.equalTo(self.view.snp_centerX)
        }
    }
    
    
    func setUpTimer(){
        timer = NSTimer.scheduledTimerWithTimeInterval(3, target: self, selector: #selector(timerChanged), userInfo: nil, repeats: true)
        NSRunLoop.currentRunLoop().addTimer(self.timer, forMode: NSRunLoopCommonModes)
    }
    

    
    func  playBackStateChange() {}
    func  pageChanged(pageControl:UIPageControl) {
        
        let flag = CGFloat(pageControl.currentPage) * self.view.bounds.size.width
        
        self.scrollView.setContentOffset(CGPointMake(flag, 0), animated: true)
    }
    
    func timerChanged(){
        let page = (self.pageControl.currentPage + 1)%4
        self.pageControl.currentPage = page
        self.pageChanged(pageControl)
    }
    
    
    func scrollViewWillBeginDragging(scrollView: UIScrollView) {
        self.timer .invalidate()
        
    }
    
    func scrollViewDidEndDecelerating(scrollView: UIScrollView) {
        
        let page = Int(self.scrollView.contentOffset.x / self.view.bounds.width)
        self.pageControl.currentPage = page
        
        if page == -1{
            UIView.animateWithDuration(0.3, animations: { 
                self.pageControl.currentPage = 3
            })
        }else if page == 4{
            
            UIView.animateWithDuration(0.3, animations: { 
                
                self.pageControl.currentPage = 0
                self.scrollView.setContentOffset(CGPointMake(0, 0), animated: true)
            })
        }
    }
    
    
    func scrollViewDidEndDragging(scrollView: UIScrollView, willDecelerate decelerate: Bool) {
        
        self.setUpTimer()
    }
    
    
    override func prefersStatusBarHidden() -> Bool {
        return true
    }
    
}

